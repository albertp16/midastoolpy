# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 21:38:40 2022
Open Midas Python 
@author: albertp16 (albert pamonag) 
"""
from seismic.static import staticSeismic
